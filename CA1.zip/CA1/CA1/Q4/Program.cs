﻿double[][] Rainfall = new double[][]
{
   new double[] { 6.9, 7.1, 7.2  },
    new double[] { 6.1, 6.4, 6.3 },
    new double[] { 6.5, 6.7, 6.9 },
};

double[] averages = new double[3];
double total;


for (int i = 0; i < Rainfall.GetLength(0); i++)
{
    total = 0;

    for (int j = 0; j < Rainfall[i].Length; j++)
    {
     total += Rainfall[i][j];
    }

    averages[i] = (double)total / 3;
}

foreach (double average in averages)
{
    Console.WriteLine($"Average is {average:F2}");
}