﻿double grade = 10; 

Console.WriteLine($"Your grade is {grade}");

UpdateGrade(ref grade,  newGrade);

if (UpdateGrade(ref grade))
{
    Console.WriteLine($"Your Grade has been updated and is now {grade}");
}


static double UpdateGrade(ref double grade, double NewGrade)
{
    double result = 0;
    if (grade <= 100)
    {
        NewGrade = grade  + (grade * 0.15);
       NewGrade = result;
    }

    return result;
}
