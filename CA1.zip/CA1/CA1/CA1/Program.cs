﻿// input temperature 
Console.Write("Enter The Temperature: ");
string input = Console.ReadLine();
int temperature = int.Parse(input);

if (ValidTemp(temperature))
    Console.WriteLine("The Temperature is inside the normal range");
else Console.WriteLine("The Temperature is outside the normal range");

// Validate whether user input is true or false

static bool ValidTemp(int result)
{
    bool validTemp = false;

    if (result >= 18 && result <=22)
        validTemp = true;

    return validTemp;
}

