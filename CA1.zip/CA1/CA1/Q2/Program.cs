﻿Console.Write("Please enter your membership type >> ");

int club = 50;
string input = Console.ReadLine();
int discount;


switch (input)
{
    case "Children":
        discount = club - 25;
        break;

    case "Students":
        discount = club - 10;
        break;

    case "OAPs":
        discount = club - 5;
        break;

    default:
        discount = club - 0;
        break;


}


Console.WriteLine($"Your Total Price is {discount:c}");





