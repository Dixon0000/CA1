﻿//read file
string filePath = @"C:\Users\S00227213\OneDrive - Atlantic TU\CA1\results.txt";

try
{
    string[] fileContents = File.ReadAllLines(filePath);

    // Read Text line by line
    int result = 0;
    for (int i = 0; i < fileContents.Length; i++)
    {
        result = Convert.ToInt32(fileContents[i]);


    }

    //append file
    File.AppendAllText(filePath, Environment.NewLine);
}
catch (IOException io)
{
    Console.WriteLine(io.Message);

}