﻿using System.Security.Cryptography;
using Q6;

// create 2 objects 
ElectricBike b1 = new ElectricBike();
b1.ID = "EB1";
b1.Location = "Ash Lane";
b1.BatteryPercentage = 50;


ElectricBike b2 = new ElectricBike();
b2.ID = "EB2";
b2.Location = "Strandhill";
b2.BatteryPercentage = 10;

//display 2 objects
b1.DisplayBikeInfo();
b2.DisplayBikeInfo();

