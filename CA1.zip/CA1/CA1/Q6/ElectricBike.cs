﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q6
{
    internal class ElectricBike
    {
        private string id;

        public string ID
        {
            get { return this.ID; }
            set { this.ID = value; }
        }

        private string _location;

        public string Location
        {
            get { return Location; }
            set { Location = value; }
        }

        private int batterypercentage;

        public int BatteryPercentage
        {
            get { return BatteryPercentage; }
            set { BatteryPercentage = value; }

        }



        public void DisplayBikeInfo()
        {
            Console.WriteLine($"ID: {ID}");
            Console.WriteLine($"Locatiob: {Location}");
            Console.WriteLine($"Current Speed: {BatteryPercentage}");

        }

    }
}